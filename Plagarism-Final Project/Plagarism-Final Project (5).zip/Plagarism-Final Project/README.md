# AntiPlag
# Description
A simple plagiarism checker program written in C++/Qt. Its role is to conduct global plagiarism check.
